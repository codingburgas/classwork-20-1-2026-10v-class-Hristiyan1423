// MathLib.cpp : Defines the functions for the static library.
//

#include "pch.h"
#include "framework.h"
#include "MathLibrary.h"
#include <iostream>
using namespace std;
int perimeter(int a, int b, int c) {
	return a + b + c;
}
int plot(int a, int h) {
	return a * h / 2;
}
