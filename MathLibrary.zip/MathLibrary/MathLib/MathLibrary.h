#pragma once
int perimeter(int a, int b);
int plot(int a, int h);